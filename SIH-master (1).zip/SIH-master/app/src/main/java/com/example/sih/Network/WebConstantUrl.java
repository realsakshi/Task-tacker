package com.example.sih.Network;

public class WebConstantUrl {

    public static String BASE_URL ="http://192.168.1.15:9090/" ;
}
