package com.example.sih.Employee;

public class LetestScholershipForm {

    String name = "", amount = "", information = "";

    public LetestScholershipForm() {}

    public LetestScholershipForm(String name, String amount, String information) {
        this.name = name;
        this.amount = amount;
        this.information = information;
    }

}
